import { 
  PrintingType, 
  PackingProductCategory, 
  ServedIndustry, 
  LuxuryService, 
  LuxuryTestimonial, 
  CompanyStat 
} from './types';

export const companyStats: CompanyStat[] = [
  {
    value: "15",
    suffix: "+",
    label: "Years Experience",
    subtext: "Pioneering premium packaging"
  },
  {
    value: "500",
    suffix: "M+",
    label: "Products Delivered",
    subtext: "Globally trusted supply chain"
  },
  {
    value: "24",
    suffix: "/7",
    label: "Production Support",
    subtext: "Continuous high-speed output"
  },
  {
    value: "120",
    suffix: "+",
    label: "Brands Served",
    subtext: "From startups to Fortune 500s"
  }
];

export const printingTypes: PrintingType[] = [
  {
    id: "digital",
    title: "Digital Printing",
    description: "Ultra-sharp modern direct inkjet rendering that requires zero cylinder plates. Ideal for high-mix short runs, prompt custom campaigns, and personalized high-end presentation packages.",
    badge: "Agile & Precise",
    advantages: [
      "Zero plate setup costs and rapid prototype testing",
      "Dynamic variable data, QR, and unique serial tracking",
      "Expedited lead times for direct-to-market products"
    ],
    specs: [
      { label: "Optimal Run", value: "100 - 5,000 units" },
      { label: "Resolution", value: "Continuous tone 1200 DPI" },
      { label: "Substrates", value: "Paper, flexible polymers, metallic films" }
    ],
    accentColor: "from-purple-500/10 to-violet-500/10 border-purple-500/20"
  },
  {
    id: "rotogravure",
    title: "Rotogravure Printing",
    description: "The gold standard for ultra-high-volume flexible packaging. Carves micro-cells directly onto steel cylinders, establishing unmatched color consistency, ink density, and high-speed efficiency across millions of impressions.",
    badge: "Ultra-Volume Master",
    advantages: [
      "Consistent high speed printing (up to 400 meters/min)",
      "Unrivaled ink laydown and richness on metallic substrates",
      "Extremely long plate life for recurring high-volume jobs"
    ],
    specs: [
      { label: "Optimal Run", value: "50,000+ units" },
      { label: "Color Space", value: "Up to 10 stations (CMYK + Pantones)" },
      { label: "Max Speed", value: "450 m/min continuous" }
    ],
    accentColor: "from-blue-500/10 to-indigo-500/10 border-blue-500/20"
  },
  {
    id: "flexographic",
    title: "Flexographic Printing",
    description: "An incredibly versatile, sustainable printing technique using flexible relief plates. Delivers exceptional speeds on a vast array of substrates ranging from heavy cardboard to lightweight films.",
    badge: "Eco-Versatile",
    advantages: [
      "Extremely cost-effective for large mid-range runs",
      "Eco-friendly water-based and soy-based food-safe inks",
      "Supports inline lamination, die-cutting, and varnishing"
    ],
    specs: [
      { label: "Optimal Run", value: "10,000 - 100,000 units" },
      { label: "Ink Types", value: "Water-based, UV-curable, Solvent" },
      { label: "Max Width", value: "Up to 1300mm web widths" }
    ],
    accentColor: "from-emerald-500/10 to-teal-500/10 border-emerald-500/20"
  },
  {
    id: "offset",
    title: "Offset Printing",
    description: "Classic high-fidelity planography using aluminum plates to transfer ink via a rubber blanket. The premium standard for high-end rigid canvas folding boxes, cosmetic packaging, and structured booklets.",
    badge: "Fidelity Classic",
    advantages: [
      "Micro-fine details and sharp vector text precision",
      "Perfect color profiling for intricate premium cosmetics",
      "Highly efficient scaling for large luxury board runs"
    ],
    specs: [
      { label: "Optimal Run", value: "1,000 - 20,000 units" },
      { label: "Perfect For", value: "Thick SBS boards, textured luxury craft" },
      { label: "Specialty", value: "Spot gloss, matte coatings, embossing" }
    ],
    accentColor: "from-amber-500/10 to-orange-500/10 border-amber-500/25"
  },
  {
    id: "hybrid",
    title: "Flexo + Digital Hybrid",
    description: "The best of both worlds. Combines the speed and ink density of high-volume Flexography with the immediate customizability of industrial Digital UV inkjet modules in a single continuous line.",
    badge: "Next-Gen Fusion",
    advantages: [
      "Apply high-opacity screen block-outs first, overlay custom data last",
      "Maximize cost efficiencies on variable flavor & language runs",
      "In-line processing including cold foil stamps and spot varnishes"
    ],
    specs: [
      { label: "optimal Run", value: "5,000 - 50,000 units" },
      { label: "Uniqueness", value: "Dynamic regional labels, customized flavors" },
      { label: "Finishes", value: "Gloss lacquer, matte laminate, holographic" }
    ],
    accentColor: "from-pink-500/10 to-purple-500/10 border-pink-500/20"
  }
];

export const productCategories: PackingProductCategory[] = [
  {
    id: "pouches",
    title: "Pouches",
    description: "Ergonomic, lightweight flexible pouches optimized for freshness preservation, elegant presentation, and tactile user-appeal.",
    imagePath: "/src/assets/images/pouch_mockup_1779448959535.png",
    highlights: ["Exceptional barrier film properties", "Hermetic tear reseals", "Space & weight reducing footprint"],
    finishOptions: ["Matte velvet touch", "Metallic gloss", "Frosted/Clear windows", "Soft touch paper laminate"],
    subTypes: [
      {
        name: "Stand-up Pouches",
        description: "Equipped with a bottom gusset that expands to allow the packaging to stand upright prominently on retail shelves.",
        highlight: "Ideal for retail snacks, granular products, and artisanal blends."
      },
      {
        name: "Zipper Pouches",
        description: "Features secure grip-lock zippers that permit clients to preserve freshness through dozens of reseal cycles.",
        highlight: "Popular for organic coffee, superfood powders, and pet treats."
      },
      {
        name: "Spout Pouches",
        description: "Engineered with specialized plastic pour spouts. Safe, spill-proof alternative to heavy glass or plastic canisters.",
        highlight: "Perfect for direct liquid pour, baby purees, cosmetics, and sauces."
      },
      {
        name: "Vacuum Pouches",
        description: "Ultra-tight fit barriers that extract maximum oxygen to significantly extend product lifetimes naturally.",
        highlight: "Crucial for cheese, luxury cured meats, and fresh gourmet foods."
      }
    ]
  },
  {
    id: "boxes",
    title: "Boxes",
    description: "Sophisticated structural box packages crafted to protect heavy items while serving as an immersive luxury canvass for branding.",
    imagePath: "/src/assets/images/box_mockup_1779448977649.png",
    highlights: ["Rigid protective structures", "Foil-embossed detailing", "FSC certified sustainable pulps"],
    finishOptions: ["Debossed brand logos", "Gold & Silver hot foil stamps", "Custom insert moldings", "Ribbon pulls"],
    subTypes: [
      {
        name: "Folding Cartons",
        description: "Sleek cardstock boxes that assemble flats effortlessly. An economical yet gorgeous solution for everyday retail goods.",
        highlight: "Favored by pharmaceutical, beauty products, and tea houses."
      },
      {
        name: "Corrugated Boxes",
        description: "Reinforced fluting layers that deliver superb compressive strength for outer shipping containers and heavy electronics.",
        highlight: "Essential for reliable mailer deliveries and high-end subscription boxes."
      },
      {
        name: "Luxury Packaging Boxes",
        description: "Thick, hardboard structures wrapped in premium papers with modern magnetic closures and slide-out compartments.",
        highlight: "Exquisite presentations for elite jewelry, expensive perfumes, and tech flagships."
      }
    ]
  },
  {
    id: "canisters",
    title: "Canisters",
    description: "Cylindrical composite tubes combining metallic, clean plastic, and fine organic kraft fibers for distinct shelf presence.",
    imagePath: "/src/assets/images/canister_mockup_1779448996973.png",
    highlights: ["Aesthetic 360° cylindrical space", "Hermetic metal closures", "Reusable luxury feel"],
    finishOptions: ["Eco-craft paper wrap", "UV gloss outer shield", "Metallic silver lid finishes", "Textured spiral wraps"],
    subTypes: [
      {
        name: "Premium Tube Canisters",
        description: "Perfect spiral wound high-density cardboard cores capped with metal or bamboo lids for a rich heritage appeal.",
        highlight: "Preferred for loose teas, aged single malts, and natural cosmetics."
      },
      {
        name: "Protective Retail Cannons",
        description: "Tear-resistant outer layers suited to shield fragile bottled goods during transit while maintaining majestic layouts.",
        highlight: "Exudes confidence on boutique shelving floors."
      }
    ]
  },
  {
    id: "labels",
    title: "Labels",
    description: "Premium adhesive badges meticulously engineered to resist moisture, tearing, and high UV exposures without peeling off.",
    imagePath: "/src/assets/images/labels_mockup_1779449021945.png",
    highlights: ["Zero-peel strong self-adhesion", "Water and oil resistant shields", "Precision contour die-cut outlines"],
    finishOptions: ["Clear matte look", "Holographic chrome shine", "Tactile textured paper", "Embossed security seals"],
    subTypes: [
      {
        name: "Barcode Labels",
        description: "Strict high-contrast vector codes verified to scan flawless under industrial warehouse readers and checkout terminals.",
        highlight: "Includes variable batch serials, standard barcodes, and micro QR codes."
      },
      {
        name: "Product Labels",
        description: "Fully customized spot varnished front faces configured to hold up beautifully against condensation inside refrigerators.",
        highlight: "Suited for gourmet condiments, cold brews, and premium wines."
      },
      {
        name: "Transparent Labels",
        description: "High-clarity clear backings that vanish onto glass or plastic containers, creating a high-end 'direct print' effect.",
        highlight: "Highly popular for pure spirits, premium cosmetics, and minimalist health serums."
      }
    ]
  },
  {
    id: "sleeves",
    title: "Sleeves",
    description: "360-degree heat-shrinkable films that conform perfectly to irregular bottle shapes, maximizing visual storytelling real estate.",
    imagePath: "/src/assets/images/labels_mockup_1779449021945.png", // reusing the label mockup with a toggle
    highlights: ["Contour-conforming shrink fit", "Tamper-evident neck cap seals", "Vibrant full-height printing coverage"],
    finishOptions: ["Soft matte touch coating", "Full holographic layers", "Metallic underlying foils", "Perforated pull tabs"],
    subTypes: [
      {
        name: "Full Body Bottles",
        description: "Envelops containers from the bottom bead to the throat, facilitating gorgeous 360-degree layout designs.",
        highlight: "Popular for dairy beverages, functional energy juices, and craft beers."
      },
      {
        name: "Tamper-Evident Headbands",
        description: "Includes easy micro-perforations at the neck to guarantee complete freshness and absolute customer security.",
        highlight: "Standard for premium health goods, sauces, and delicate foods."
      }
    ]
  }
];

export const servedIndustries: ServedIndustry[] = [
  {
    id: "spices",
    name: "Spices & Herbs",
    description: "Hermetic high-barrier foils that prevent ambient moisture from clumping delicate ground seasonings while sealing in rich organic aromas.",
    iconName: "Flame",
    bgColor: "from-amber-500/5 to-orange-600/5",
    accentClass: "bg-amber-500 text-amber-700"
  },
  {
    id: "dryfruits",
    name: "Dry Fruits & Nuts",
    description: "Robust nitrogen flushed zippers and clear preview windows showcase natural crunchiness while acting as an impenetrable light and gas shield.",
    iconName: "Apple",
    bgColor: "from-yellow-600/5 to-amber-700/5",
    accentClass: "bg-yellow-600 text-yellow-800"
  },
  {
    id: "frozen",
    name: "Frozen Foods",
    description: "Frost-engineered substrates built explicitly to resist cracking at sub-zero temperatures (down to -40°C), blocking oxygen completely.",
    iconName: "Snowflake",
    bgColor: "from-sky-400/5 to-blue-600/5",
    accentClass: "bg-sky-500 text-sky-700"
  },
  {
    id: "retail",
    name: "Premium Retail",
    description: "Stately sliding trays, luxurious magnetic closures, and elegant foil stamps crafted to prompt exciting unboxing sensations for buyers.",
    iconName: "ShoppingBag",
    bgColor: "from-purple-500/5 to-indigo-600/5",
    accentClass: "bg-purple-500 text-purple-700"
  },
  {
    id: "fmcg",
    name: "Fast FMCG Products",
    description: "Efficient high-speed roll stock film rolls and labels configured to synchronize with automated packaging machinery lines flawlessly.",
    iconName: "Boxes",
    bgColor: "from-emerald-500/5 to-teal-600/5",
    accentClass: "bg-emerald-500 text-emerald-700"
  },
  {
    id: "food",
    name: "Food & Beverage",
    description: "100% FDA/EU food-safe materials, water-solvent inks, and anti-fog membranes keeping foods organic, colorful, and deliciously fresh.",
    iconName: "ChefHat",
    bgColor: "from-rose-500/5 to-pink-600/5",
    accentClass: "bg-rose-500 text-rose-700"
  }
];

export const luxuryServices: LuxuryService[] = [
  {
    id: "designing",
    title: "Bespoke Packaging Design",
    description: "Our industrial packaging designers draft custom structural die-lines and elegant creative layout renderings customized to your item's dimensional curves.",
    iconName: "PenTool",
    benefits: ["Custom 3D fold-checks", "High-fidelity photorealistic pre-renders", "Eco-structure engineering"]
  },
  {
    id: "machinery",
    title: "Machinery Solutions Integration",
    description: "We don't just supply boxes. We consult with engineers to align flexible films and pre-formed pouches with high-speed filling, sealing, and packaging loops.",
    iconName: "Cpu",
    benefits: ["Sealing jaw compatibility checks", "Form-fill-seal film optimization", "Line automation audits"]
  },
  {
    id: "labelling",
    title: "Custom Labelling Schemes",
    description: "Develop seamless adhesive materials targeted for high-humidity, intense heat, or sub-zero environments to ensure label corners never peel.",
    iconName: "Tag",
    benefits: ["Extreme condition testing", "Roll feed direction setup", "Die-line configuration support"]
  },
  {
    id: "barcode",
    title: "GS1 Barcode Compliance Help",
    description: "Ensure error-free distribution. We generate, format, and place high-contrast GS1 barcodes, QR codes, and nutritional tables in strict regulatory compliance.",
    iconName: "QrCode",
    benefits: ["100% scan clarity verification", "Dynamic variable QR databases", "Global regulatory compliance checks"]
  },
  {
    id: "converter",
    title: "High-Speed Converter Services",
    description: "Advanced slitting, laminating, and sheeting machinery converting giant film masters into exact roll widths or custom-cut packaging elements.",
    iconName: "Layers",
    benefits: ["Precision slitting tolerances", "Multi-layer laminations", "Prompt custom order deliveries"]
  }
];

export const clientTestimonials: LuxuryTestimonial[] = [
  {
    id: "1",
    quote: "MPACK raised our product line's perception from standard retail to high-end boutique. The velvet-touch matte stand-up pouches feel incredibly luxurious, and their custom metallic ink is flawless. Their physical mockups saved us thousands in structural mistakes.",
    author: "Elena Rostov",
    role: "Director of Brand",
    company: "Aura Botanical Cosmetics",
    rating: 5,
    initials: "ER"
  },
  {
    id: "2",
    quote: "The hybrid flexo-digital service is amazing. We ran 15 separate flavor batches in standard low quantities, and each design has continuous tone 1200 DPI resolution with zero copper cylinder plate expenses. Absolute game changer.",
    author: "Marcus Van Der Berg",
    role: "Founder & Master Roaster",
    company: "Solstice Craft Coffee Co.",
    rating: 5,
    initials: "MB"
  },
  {
    id: "3",
    quote: "We require packaging film rolls that run 300 cycles/min on our robotic form-fill-seal machines. Other printers struggle with thermal sealing tolerances, but MPACK's materials run perfectly clean with zero friction blockages.",
    author: "Klaus Sterling",
    role: "Operations Director",
    company: "Gourmet Foods Group",
    rating: 5,
    initials: "KS"
  },
  {
    id: "4",
    quote: "The geometric precision of their luxury gift boxes is astounding. The silent magnetic shut feel, crisp alignment, and thick material board make our perfume feel like an pure art installation. Extremely recommended.",
    author: "Sienna Chloé",
    role: "Creative Lead",
    company: "Maison de L'Arôme",
    rating: 5,
    initials: "SC"
  }
];
