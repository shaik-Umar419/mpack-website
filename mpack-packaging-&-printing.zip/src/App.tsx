import { useState } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import About from './components/About';
import PrintingTypes from './components/PrintingTypes';
import ProductShowcase from './components/ProductShowcase';
import Industries from './components/Industries';
import OtherServices from './components/OtherServices';
import Testimonials from './components/Testimonials';
import Contact from './components/Contact';
import LoadingScreen from './components/LoadingScreen';
import { Layers, ArrowUp } from 'lucide-react';

export default function App() {
  const [isLoading, setIsLoading] = useState(true);

  const scrollToContact = () => {
    const contactSec = document.getElementById('contact');
    if (contactSec) {
      contactSec.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToExplore = () => {
    const showcaseSec = document.getElementById('showcase');
    if (showcaseSec) {
      showcaseSec.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  if (isLoading) {
    return <LoadingScreen onComplete={() => setIsLoading(false)} />;
  }

  return (
    <div className="relative min-h-screen bg-[#fcfbfe] text-gray-800 font-sans antialiased overflow-hidden selection:bg-violet-100 selection:text-violet-900">
      
      {/* Floating Header */}
      <Header onContactClick={scrollToContact} />

      {/* Main Single Page Contents */}
      <main>
        <Hero 
          onContactClick={scrollToContact} 
          onExploreClick={scrollToExplore} 
        />
        
        <About />
        
        <PrintingTypes />
        
        <ProductShowcase />
        
        <Industries />
        
        <OtherServices />
        
        <Testimonials />
        
        <Contact />
      </main>

      {/* Infinite Elegant Footer */}
      <footer className="bg-gray-950 text-white pt-20 pb-12 relative overflow-hidden border-t border-gray-950">
        
        {/* Subtle glow sphere behind footer */}
        <div className="absolute top-0 right-1/4 w-80 h-80 rounded-full bg-violet-600/10 blur-[80px] pointer-events-none" />

        <div className="max-w-7xl mx-auto px-6 md:px-12 relative z-10">
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 pb-16 border-b border-white/5">
            
            {/* Column 1 Logo */}
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 rounded-full bg-violet-600 flex items-center justify-center">
                  <Layers className="w-4 h-4 text-white" />
                </div>
                <div>
                  <span className="font-display font-medium text-sm tracking-[0.2em] uppercase text-white block">
                    Mpack
                  </span>
                  <span className="text-[7px] font-mono tracking-widest text-violet-400 uppercase leading-none block">
                    Packaging & Printing
                  </span>
                </div>
              </div>
              <p className="font-sans text-xs text-gray-400 font-light max-w-xs leading-relaxed">
                Elite physical brand presentation systems that protect item shelf-lives and command immediate purchase premiums in luxury retail corridors.
              </p>
            </div>

            {/* Column 2: Quick Links */}
            <div className="space-y-4">
              <h4 className="text-xs font-mono uppercase tracking-widest text-[#a855f7] font-semibold">
                Technology
              </h4>
              <ul className="space-y-2.5 text-xs font-sans font-light text-gray-400">
                <li><a href="#printing-tech" className="hover:text-white transition-colors">Digital Prepress Engraving</a></li>
                <li><a href="#printing-tech" className="hover:text-white transition-colors">Rotogravure Steel Cylinder</a></li>
                <li><a href="#printing-tech" className="hover:text-white transition-colors">High-Speed Flexographic Systems</a></li>
                <li><a href="#printing-tech" className="hover:text-white transition-colors">Flexo-Digital Hybrid Lines</a></li>
              </ul>
            </div>

            {/* Column 3: Catalogs */}
            <div className="space-y-4">
              <h4 className="text-xs font-mono uppercase tracking-widest text-[#a855f7] font-semibold">
                Core Formats
              </h4>
              <ul className="space-y-2.5 text-xs font-sans font-light text-gray-400">
                <li><a href="#showcase" className="hover:text-white transition-colors">Stand-up & Vacuum Pouches</a></li>
                <li><a href="#showcase" className="hover:text-white transition-colors">Rigid Sliding Gift Boxes</a></li>
                <li><a href="#showcase" className="hover:text-white transition-colors">Eco-kraft Cylinder Canisters</a></li>
                <li><a href="#showcase" className="hover:text-white transition-colors">Condensation-Resistant Labels</a></li>
              </ul>
            </div>

            {/* Column 4: Operational Duty */}
            <div className="space-y-4">
              <h4 className="text-xs font-mono uppercase tracking-widest text-[#a855f7] font-semibold">
                Global Operations
              </h4>
              <div className="text-xs font-sans font-light text-gray-400 space-y-1">
                <p>Sydney HQ: 24/7 Production Yard</p>
                <p>Tokyo Hub: Material Research Lab</p>
                <p className="pt-2 text-[10px] text-violet-400 font-mono tracking-wider">FDA / ISO 9001 / FSC CERTIFIED</p>
              </div>
            </div>

          </div>

          {/* Copyright banner */}
          <div className="pt-8 flex flex-col sm:flex-row items-center justify-between text-gray-500 text-[10.5px] font-sans gap-4">
            <div className="flex items-center space-x-1">
              <span>© {new Date().getFullYear()} MPACK Packaging & Printing Solutions. All Rights Reserved.</span>
            </div>
            
            <div className="flex items-center space-x-6">
              <a href="#about" className="hover:text-white transition-colors">Privacy Charter</a>
              <a href="#about" className="hover:text-white transition-colors">Security Seals Audit</a>
              <button
                onClick={scrollToTop}
                className="flex items-center space-x-1.5 hover:text-white transition-all text-violet-400 bg-white/5 border border-white/10 px-3 py-1 rounded-full cursor-pointer"
              >
                <span>Ascend Top</span>
                <ArrowUp className="w-3.5 h-3.5 animate-bounce" />
              </button>
            </div>
          </div>

        </div>

      </footer>

    </div>
  );
}

