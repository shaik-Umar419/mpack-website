export interface PrintingType {
  id: string;
  title: string;
  description: string;
  badge: string;
  advantages: string[];
  specs: { label: string; value: string }[];
  accentColor: string;
}

export interface ProductSubType {
  name: string;
  description: string;
  highlight: string;
}

export interface PackingProductCategory {
  id: string;
  title: string;
  description: string;
  imagePath: string;
  subTypes: ProductSubType[];
  highlights: string[];
  finishOptions: string[];
}

export interface ServedIndustry {
  id: string;
  name: string;
  description: string;
  iconName: string;
  bgColor: string;
  accentClass: string;
}

export interface LuxuryService {
  id: string;
  title: string;
  description: string;
  iconName: string;
  benefits: string[];
}

export interface LuxuryTestimonial {
  id: string;
  quote: string;
  author: string;
  role: string;
  company: string;
  rating: number;
  initials: string;
}

export interface CompanyStat {
  value: string;
  label: string;
  suffix: string;
  subtext: string;
}
