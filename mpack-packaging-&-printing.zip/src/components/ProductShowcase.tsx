import { useState, ChangeEvent } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, ArrowRight, Layers, Eye, CheckCircle2, ChevronRight, Upload, Info } from 'lucide-react';
import { productCategories } from '../data';

export default function ProductShowcase() {
  const [activeTab, setActiveTab] = useState<string>("pouches");
  
  // Customizer simulator state
  const [selectedFinish, setSelectedFinish] = useState<string>("matte-gold");
  const [uploadedLogo, setUploadedLogo] = useState<string | null>(null);
  const [isSimulating, setIsSimulating] = useState(false);

  const activeCategory = productCategories.find(cat => cat.id === activeTab) || productCategories[0];

  const finishSimulators = [
    { id: "matte-gold", name: "Matte Velvet + Gold Hotfoil", desc: "A soft, non-reflective surface paired with high-contrast warm golden metallic stamp profiles.", glowColor: "from-amber-400 bg-amber-500/10 border-amber-400/40 text-amber-700" },
    { id: "soft-silver", name: "Textured Craft + Silver Spot", desc: "Eco-friendly fibrous natural paper fibers with micro-embossed cool silver metallic elements.", glowColor: "from-slate-300 bg-slate-300/10 border-slate-300/40 text-slate-800" },
    { id: "chrome-holo", name: "Metallic Chrome + Holographic", desc: "Vibrant shifting rainbow spectrum layer applied selectively to stand out under point-source retail light.", glowColor: "from-pink-400 via-purple-400 to-cyan-400 bg-purple-500/15 border-purple-300/40 text-violet-700" },
  ];

  const handleLogoUpload = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setUploadedLogo(reader.result as string);
        setIsSimulating(true);
        setTimeout(() => setIsSimulating(false), 1200); // simulation wave animation run
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <section id="showcase" className="relative py-28 bg-[#F8F9FD] overflow-hidden scroll-mt-20">
      
      {/* Dynamic Floating Ambient Glow lights */}
      <div className="absolute top-[20%] left-[-15%] w-[45vw] h-[45vw] rounded-full bg-purple-100/30 blur-[130px] animate-glow-pulse-1 pointer-events-none" />
      <div className="absolute bottom-[20%] right-[-15%] w-[45vw] h-[45vw] rounded-full bg-blue-50/20 blur-[130px] animate-glow-pulse-2 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 md:px-12 relative z-10">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div className="space-y-4 max-w-xl">
            <div className="inline-flex items-center space-x-2 bg-white border border-purple-100/80 px-3 py-1 rounded-full shadow-xs">
              <span className="w-1.5 h-1.5 rounded-full bg-purple-500" />
              <span className="text-[10px] font-sans font-bold tracking-widest text-[#a855f7] uppercase">
                Creative Catalog
              </span>
            </div>
            <h2 className="text-3xl md:text-5xl font-light tracking-tight text-slate-900 leading-[1.05]">
              Structural <span className="font-serif italic text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-blue-500">Categories</span> & Catalogs
            </h2>
            <p className="font-sans text-sm md:text-base text-slate-500 font-light leading-relaxed">
              Discover why top international consumer brands choose our five specialized structural product frameworks. Select tabs to explore nested subsets.
            </p>
          </div>

          {/* Tab Selector Links */}
          <div className="flex flex-wrap gap-1.5 bg-white p-1.5 rounded-2xl border border-slate-100 w-fit self-start md:self-end shadow-xs">
            {productCategories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setActiveTab(cat.id)}
                className={`px-5 py-2.5 rounded-xl text-xs font-sans font-semibold tracking-wider uppercase transition-all duration-300 cursor-pointer ${
                  activeTab === cat.id
                    ? 'bg-[#F8F9FD] text-purple-700 shadow-xs border border-purple-100/50 font-bold'
                    : 'text-slate-400 hover:text-slate-700 hover:bg-slate-50'
                }`}
              >
                {cat.title}
              </button>
            ))}
          </div>
        </div>

        {/* Major Visual Tab Content Split Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start mb-24">
          
          {/* Left Column: Glass Showcase Card */}
          <div className="lg:col-span-5 relative">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeCategory.id}
                initial={{ opacity: 0, scale: 0.96 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.96 }}
                transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
                className="relative bg-white border border-slate-100 rounded-[2.5rem] p-4 shadow-xl shadow-purple-100/10 group overflow-hidden"
              >
                {/* Visual Pedestal pedestal lines */}
                <div className="absolute inset-x-0 bottom-0 h-40 bg-gradient-to-t from-purple-50/20 to-transparent pointer-events-none" />
                
                {/* Image Box */}
                <div className="relative aspect-[4/3] rounded-[1.8rem] overflow-hidden bg-slate-50 border border-slate-100">
                  <img
                    src={activeCategory.imagePath}
                    alt={activeCategory.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover transform transition-transform duration-1000 group-hover:scale-105"
                  />

                  {/* Absolute Corner Indicators */}
                  <div className="absolute top-4 left-4 bg-slate-900/85 backdrop-blur-md text-white text-[9px] font-mono tracking-widest px-3 py-1 rounded-full uppercase">
                    Model Ref:{activeCategory.id}-2026
                  </div>
                </div>

                {/* Categories specs underneath image */}
                <div className="p-6 space-y-6">
                  <div>
                    <h3 className="text-xl font-light text-slate-900 tracking-tight mb-2">
                      {activeCategory.title} Specifications
                    </h3>
                    <p className="font-sans text-xs text-slate-500 font-light leading-relaxed">
                      {activeCategory.description}
                    </p>
                  </div>

                  <div className="space-y-2.5">
                    <span className="text-[9px] font-mono tracking-widest text-[#a855f7] uppercase font-semibold block">
                      Integrated Finish Solutions:
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {activeCategory.finishOptions.map((f) => (
                        <span
                          key={f}
                          className="bg-[#F8F9FD] border border-purple-100/50 text-[#a855f7] text-[10px] font-sans px-3 py-1 rounded-full font-medium"
                        >
                          {f}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="pt-5 border-t border-slate-100 grid grid-cols-2 gap-4">
                    {activeCategory.highlights.map((hl, i) => (
                      <div key={i} className="flex items-center space-x-2">
                        <CheckCircle2 className="w-3.5 h-3.5 text-[#a855f7] shrink-0" />
                        <span className="font-sans text-[11.5px] text-slate-600 font-light">
                          {hl}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

              </motion.div>
            </AnimatePresence>
          </div>

          {/* Right Column: Layering Cards showing nested Sub-types */}
          <div className="lg:col-span-7 space-y-6">
            <span className="text-[10px] uppercase font-mono tracking-[0.25em] text-slate-300 block mb-2 font-bold">
              Nested Categories & Selections
            </span>

            <AnimatePresence mode="popLayout">
              {activeCategory.subTypes.map((sub, index) => (
                <motion.div
                  key={sub.name}
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.5, delay: index * 0.1, ease: [0.16, 1, 0.3, 1] }}
                  className="bg-white hover:bg-purple-50/[0.01] border border-slate-100 hover:border-purple-100/60 p-6 md:p-8 rounded-[2rem] shadow-xs hover:shadow-lg transition-all duration-500 flex flex-col sm:flex-row sm:items-start justify-between gap-6 group cursor-default"
                >
                  <div className="space-y-2.5 flex-1 max-w-lg">
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 rounded-full bg-[#a855f7] group-hover:scale-150 transition-transform" />
                      <h4 className="text-base font-medium text-slate-800 group-hover:text-purple-600 transition-colors">
                        {sub.name}
                      </h4>
                    </div>
                    <p className="font-sans text-[13px] text-slate-500 font-light leading-relaxed">
                      {sub.description}
                    </p>
                  </div>

                  <div className="bg-[#F8F9FD] border border-purple-50 rounded-2xl p-3 sm:max-w-[200px] text-left shrink-0">
                    <span className="text-[8px] font-mono uppercase tracking-wider text-slate-400 block font-semibold">
                      Recommended Duty
                    </span>
                    <span className="font-sans font-medium text-[11px] text-[#a855f7] leading-tight block mt-1">
                      {sub.highlight}
                    </span>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>

        </div>

        {/* LUXURY INTERACTIVE FINISH SIMULATOR WIDGET */}
        <div id="finish-simulator" className="border border-purple-100/40 bg-white rounded-[2.5rem] p-8 sm:p-12 shadow-xl shadow-purple-100/10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Widget Left Details */}
            <div className="lg:col-span-5 space-y-6">
              <div className="inline-flex items-center space-x-2 bg-[#F8F9FD] border border-purple-100/60 text-[#a855f7] px-3.5 py-1 rounded-full text-[10px] font-mono uppercase tracking-wider shadow-xs">
                <Layers className="w-3.5 h-3.5 mr-1" />
                Live Materials Lab
              </div>
              
              <div className="space-y-3">
                <h3 className="text-2xl sm:text-3xl font-light text-slate-900 tracking-tight">
                  Creative <span className="font-serif italic text-[#a855f7]">Finish Lab</span>
                </h3>
                <p className="font-sans text-sm text-slate-500 leading-relaxed font-light">
                  Simulate premium manufacturing coatings before placement. Upload your custom PNG branding mark or logotype directly to preview simulated reflection states.
                </p>
              </div>

              {/* Upload Branding logotype */}
              <div className="space-y-3">
                <span className="text-[10px] font-mono tracking-widest text-[#a855f7] uppercase font-bold">
                  1. Affix Brand Logotype
                </span>
                
                <div className="flex items-center space-x-4">
                  <label className="flex items-center space-x-2 px-4 py-2.5 rounded-full border border-dashed border-purple-200 hover:border-purple-400 bg-[#F8F9FD] hover:bg-purple-100/20 cursor-pointer text-xs font-sans font-semibold text-slate-600 transition-all">
                    <Upload className="w-4 h-4 text-[#a855f7]" />
                    <span>Upload PNG Logo</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleLogoUpload}
                      className="hidden"
                    />
                  </label>
                  
                  {uploadedLogo ? (
                    <button
                      onClick={() => setUploadedLogo(null)}
                      className="text-[10px] font-mono text-pink-500 hover:underline cursor-pointer"
                    >
                      Remove Logo
                    </button>
                  ) : (
                    <span className="text-[11px] font-sans text-slate-400 font-light">
                      Or use default brand icon
                    </span>
                  )}
                </div>
              </div>

              {/* Finish Pickers */}
              <div className="space-y-3">
                <span className="text-[10px] font-mono tracking-widest text-[#a855f7] uppercase font-bold">
                  2. Choose Finish Compound
                </span>

                <div className="flex flex-col space-y-2.5">
                  {finishSimulators.map((item) => (
                    <button
                      key={item.id}
                      onClick={() => setSelectedFinish(item.id)}
                      className={`text-left p-3.5 rounded-2xl border transition-all cursor-pointer flex items-start space-x-3 ${
                        selectedFinish === item.id
                          ? 'bg-[#F8F9FD] border-[#a855f7]/30 shadow-xs'
                          : 'bg-white hover:bg-[#F8F9FD]/60 border-slate-100 hover:border-slate-200'
                      }`}
                    >
                      <div className={`w-3.5 h-3.5 rounded-full mt-1 shrink-0 bg-gradient-to-tr ${item.glowColor}`} />
                      <div>
                        <span className="font-sans font-semibold text-xs text-slate-800 block">
                          {item.name}
                        </span>
                        <span className="font-sans text-[11px] text-slate-400 font-light block leading-tight mt-0.5">
                          {item.desc}
                        </span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

            </div>

            {/* Widget Right Canvas Renderer */}
            <div className="lg:col-span-7 flex flex-col items-center">
              
              {/* Virtual Render Chamber wrapper */}
              <div className="relative w-full max-w-[420px] aspect-square rounded-[2rem] bg-linear-to-b from-[#f1f5f9] to-[#e2e8f0] border border-white/60 p-6 flex flex-col items-center justify-center overflow-hidden shadow-inner group">
                
                {/* Simulated glare lights */}
                <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/5 to-white/40 opacity-70 pointer-events-none" />

                {/* Floating shadow pedestal */}
                <div className="absolute bottom-6 w-32 h-6 rounded-full bg-slate-900/10 blur-md" />

                {/* Animated Simulation Wave overlay */}
                <AnimatePresence>
                  {isSimulating && (
                    <motion.div
                      initial={{ top: "-10%" }}
                      animate={{ top: "110%" }}
                      exit={{ opacity: 0 }}
                      transition={{ duration: 1.2, ease: "easeInOut" }}
                      className="absolute left-0 right-0 h-4 bg-linear-to-b from-transparent via-[#a855f7]/40 to-transparent pointer-events-none z-10"
                    />
                  )}
                </AnimatePresence>

                {/* 2D mockup visual mockup model based on selections */}
                <motion.div
                  animate={{ 
                    y: [0, -6, 0],
                    rotateZ: [0, 0.5, 0]
                  }}
                  transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
                  className="relative w-44 h-64 rounded-[2rem] bg-white border border-white shadow-2xl flex flex-col items-center justify-between p-6 overflow-hidden transform-gpu"
                >
                  
                  {/* Dynamic Color Foil background applied overlays */}
                  {selectedFinish === 'matte-gold' && (
                    <div className="absolute inset-0 bg-radial from-amber-500/[0.03] to-transparent pointer-events-none" />
                  )}
                  {selectedFinish === 'soft-silver' && (
                    <div className="absolute inset-0 bg-[#fafafa] opacity-95 noise-effect pointer-events-none" />
                  )}
                  {selectedFinish === 'chrome-holo' && (
                    <div className="absolute inset-0 bg-gradient-to-tr from-pink-400/5 via-purple-300/10 to-cyan-400/5 mix-blend-color pointer-events-none" />
                  )}

                  {/* Top Seal notch zip */}
                  <div className="w-full flex flex-col items-center space-y-1">
                    <div className="w-16 h-1 bg-slate-100 rounded-full" />
                    <div className="w-full h-[1px] bg-slate-50" />
                  </div>

                  {/* Custom branding placeholder / user logo content */}
                  <div className="flex flex-col items-center justify-center text-center space-y-3 relative z-10 my-auto">
                    {uploadedLogo ? (
                      <img
                        src={uploadedLogo}
                        alt="Simulated Custom Seal Logo"
                        referrerPolicy="no-referrer"
                        className="max-h-16 max-w-28 object-contain opacity-95 transition-all"
                      />
                    ) : (
                      <div className="w-10 h-10 rounded-full border border-purple-100 bg-[#F8F9FD] flex items-center justify-center select-none text-[#a855f7] font-sans font-extrabold text-xs">
                        MP
                      </div>
                    )}
                    
                    <div className="space-y-1.5">
                      <span className={`text-[9px] uppercase font-mono tracking-widest ${
                        selectedFinish === 'matte-gold' ? 'text-amber-600 font-medium' :
                        selectedFinish === 'soft-silver' ? 'text-slate-600 font-medium' :
                        'text-purple-600 font-medium'
                      }`}>
                        {selectedFinish === 'matte-gold' ? 'Gold Foil Ink' :
                         selectedFinish === 'soft-silver' ? 'Silver Press' :
                         'Fine Holograph'}
                      </span>
                      
                      <h5 className="text-[12px] font-sans font-medium tracking-tight text-slate-800 leading-tight">
                        Organic Gourmet Blend
                      </h5>
                    </div>
                  </div>

                  {/* Bottom details label */}
                  <div className="w-full text-center relative z-10 pt-2 border-t border-slate-50">
                    <span className="text-[8px] font-mono tracking-widest text-slate-400 uppercase">
                      Premium Stand-up Gusset
                    </span>
                  </div>

                </motion.div>

                {/* Light Reflection highlights */}
                <div className="absolute top-1/4 right-1/4 w-32 h-32 rounded-full bg-purple-400/10 blur-2xl animate-glow-pulse-1 pointer-events-none" />

              </div>

              {/* Specs disclaimer */}
              <div className="mt-4 flex items-center space-x-2 text-slate-400 max-w-sm text-center">
                <Info className="w-3.5 h-3.5 text-purple-400 shrink-0" />
                <span className="text-[10px] font-sans font-light">
                  Simulated preview. Custom finishes are structured mathematically at physical printing setup sheets to match precise Pantone references.
                </span>
              </div>

            </div>

          </div>
        </div>

      </div>
    </section>
  );
}
