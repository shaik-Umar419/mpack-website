import { motion } from 'motion/react';
import { ArrowUpRight, ArrowRight, Sparkles, Box, Droplets, Compass, Tag, Cpu } from 'lucide-react';
import { companyStats } from '../data';

interface HeroProps {
  onContactClick: () => void;
  onExploreClick: () => void;
}

export default function Hero({ onContactClick, onExploreClick }: HeroProps) {
  // Mini elements for floating chips
  const floatingPills = [
    { label: 'Pouches', icon: Droplets, top: '12%', left: '8%', delay: 0.2 },
    { label: 'Boxes', icon: Box, top: '22%', right: '5%', delay: 0.5 },
    { label: 'Canisters', icon: Compass, top: '55%', left: '4%', delay: 0.8 },
    { label: 'Labels', icon: Tag, bottom: '15%', right: '8%', delay: 1.1 },
    { label: 'Custom Sleeves', icon: Cpu, bottom: '8%', left: '16%', delay: 1.4 },
  ];

  return (
    <section className="relative min-h-screen pt-32 pb-20 flex flex-col justify-center bg-[#F8F9FD] overflow-hidden">
      {/* Animated Background Glows from Design HTML */}
      <div className="absolute top-[-10%] left-[-5%] w-[40%] h-[50%] bg-purple-200 rounded-full blur-[120px] opacity-40 pointer-events-none animate-glow-pulse-1" />
      <div className="absolute bottom-[-10%] right-[-5%] w-[40%] h-[50%] bg-blue-100 rounded-full blur-[120px] opacity-50 pointer-events-none animate-glow-pulse-2" />
      <div className="absolute top-[20%] right-[10%] w-[30%] h-[40%] bg-violet-100 rounded-full blur-[100px] opacity-30 pointer-events-none" />
      
      {/* Cinematic subtle grid backdrop */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808006_1px,transparent_1px),linear-gradient(to_bottom,#80808006_1px,transparent_1px)] bg-[size:32px_32px] pointer-events-none" />

      <div className="relative z-10 max-w-7xl mx-auto px-6 md:px-12 w-full grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
        
        {/* Left Side: Editorial Typography & Actions */}
        <div className="lg:col-span-7 flex flex-col justify-center space-y-8">
          
          {/* Tagline */}
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
            className="inline-flex items-center space-x-2 bg-white border border-purple-100/80 px-3.5 py-1.5 rounded-full w-fit shadow-xs"
          >
            <span className="flex h-2 w-2 rounded-full bg-purple-500"></span>
            <span className="text-[10px] font-sans font-bold uppercase tracking-widest text-purple-600">
              Elite Creative Agency Style
            </span>
          </motion.div>

          {/* Headline - Split layout for elegant text reveal */}
          <h1 className="text-5xl sm:text-6xl lg:text-7xl font-light tracking-tighter leading-[0.95] text-slate-900 pb-1">
            <motion.span
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1, ease: [0.16, 1, 0.3, 1], delay: 0.1 }}
              className="block"
            >
              Premium
            </motion.span>
            <motion.span
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1, ease: [0.16, 1, 0.3, 1], delay: 0.2 }}
              className="italic font-serif block text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-blue-500 py-1"
            >
              Packaging
            </motion.span>
            <motion.span
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1, ease: [0.16, 1, 0.3, 1], delay: 0.3 }}
              className="block"
            >
              & Printing.
            </motion.span>
          </h1>

          {/* Subheadline */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, ease: [0.16, 1, 0.3, 1], delay: 0.4 }}
            className="text-base md:text-lg text-slate-500 max-w-md leading-relaxed font-light"
          >
            Helping brands stand out with high-quality printing, labeling, and bespoke product presentation solutions.
          </motion.p>

          {/* Interactive CTAs */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, ease: [0.16, 1, 0.3, 1], delay: 0.5 }}
            className="flex items-center space-x-4"
          >
            <button
              onClick={onExploreClick}
              className="px-8 py-4 bg-slate-900 text-white rounded-full font-medium hover:bg-slate-800 transition-all shadow-xl shadow-slate-200 hover:-translate-y-0.5 flex items-center space-x-2 cursor-pointer"
            >
              <span>Explore Services</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={onContactClick}
              className="px-8 py-4 bg-white/95 shadow-sm border border-slate-100 rounded-full text-slate-800 hover:shadow-md hover:bg-white hover:-translate-y-0.5 transition-all font-medium flex items-center space-x-1.5 cursor-pointer"
            >
              <span>Contact Us</span>
              <ArrowUpRight className="w-4 h-4 text-slate-400" />
            </button>
          </motion.div>

          {/* Stats Counters */}
          <div className="grid grid-cols-3 gap-8 pt-8 border-t border-slate-100">
            {companyStats.map((stat, idx) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1], delay: 0.6 + idx * 0.1 }}
              >
                <div className="text-2xl md:text-3xl font-bold text-slate-800 tracking-tight flex items-baseline">
                  <span>{stat.value}</span>
                  <span className="text-purple-600 font-semibold text-lg">{stat.suffix}</span>
                </div>
                <div className="text-xs uppercase tracking-wider text-slate-400 font-semibold mt-1">
                  {stat.label}
                </div>
              </motion.div>
            ))}
          </div>

        </div>

        {/* Right Side: Showcase */}
        <div className="lg:col-span-5 relative flex items-center justify-center min-h-[420px] md:min-h-[500px]">
          
          {/* Subtle spinning glow backdrop circle */}
          <div className="absolute w-[85%] h-[85%] rounded-full bg-linear-to-tr from-purple-200/15 to-blue-200/10 blur-xl animate-[spin_40s_infinite_linear] pointer-events-none" />

          {/* Main Showcase Panel */}
          <motion.div
            initial={{ scale: 0.92, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 1.4, ease: [0.16, 1, 0.3, 1], delay: 0.2 }}
            className="relative w-full max-w-[440px] aspect-[4/3] rounded-3xl p-3 bg-linear-to-b from-white to-white/60 border border-white/80 shadow-2xl shadow-purple-100/45 backdrop-blur-md overflow-hidden hover:shadow-purple-200/50 transition-all duration-700"
          >
            {/* Soft inner glow gradient */}
            <div className="absolute inset-0 bg-radial from-purple-600/[0.03] via-transparent to-transparent pointer-events-none" />
            
            <img
              src="/src/assets/images/hero_mockup_1779448937618.png"
              alt="Premium packaging box, pouch, and canister render showcase"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover rounded-2xl transform hover:scale-[1.02] transition-transform duration-1000"
            />
          </motion.div>

          {/* Floating Luxury Elements */}
          {floatingPills.map((pill, idx) => {
            const Icon = pill.icon;
            return (
              <motion.div
                key={pill.label}
                initial={{ opacity: 0, y: 15 }}
                animate={{ 
                  opacity: 0.95, 
                  y: [0, -12, 0],
                }}
                transition={{
                  opacity: { duration: 0.8, delay: pill.delay },
                  y: {
                    duration: 5 + idx,
                    repeat: Infinity,
                    ease: "easeInOut",
                    delay: pill.delay
                  }
                }}
                style={{
                  position: 'absolute',
                  top: pill.top,
                  bottom: pill.bottom,
                  left: pill.left,
                  right: pill.right,
                }}
                className="hidden sm:flex items-center space-x-2 px-3 py-1.5 rounded-full bg-white/90 backdrop-blur-xl border border-purple-100/60 shadow-xs hover:border-purple-500/30 hover:shadow-md hover:bg-white transition-all duration-500 cursor-default group"
              >
                <div className="w-5 h-5 rounded-full bg-purple-50 flex items-center justify-center group-hover:bg-purple-100 transition-colors">
                  <Icon className="w-3 h-3 text-purple-600" />
                </div>
                <span className="text-[10px] font-sans font-semibold tracking-wider text-slate-700 uppercase">
                  {pill.label}
                </span>
              </motion.div>
            );
          })}

        </div>

      </div>

      {/* Elegant smooth-scroller path indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 0.5 }}
        transition={{ delay: 1.2 }}
        className="absolute bottom-6 left-1/2 -translate-x-1/2 flex flex-col items-center cursor-pointer pointer-events-none"
      >
        <span className="text-[9px] font-mono tracking-widest text-slate-400 uppercase mb-2">
          Scroll To Descend
        </span>
        <div className="w-[1px] h-10 bg-linear-to-b from-purple-300 to-transparent relative overflow-hidden">
          <motion.div 
            animate={{ y: [0, 40, 0] }}
            transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
            className="absolute top-0 left-0 right-0 h-4 bg-purple-600 rounded-full"
          />
        </div>
      </motion.div>
    </section>
  );
}
