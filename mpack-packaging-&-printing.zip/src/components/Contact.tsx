import { useState, FormEvent } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, Phone, Mail, MapPin, Send, CheckSquare, MessageCircle, HelpCircle } from 'lucide-react';

export default function Contact() {
  const [formData, setFormData] = useState({
    fullName: '',
    companyEmail: '',
    category: 'pouches',
    volume: '20k-50k',
    specifications: ''
  });

  const [formSubmitted, setFormSubmitted] = useState(false);
  const [submitLoading, setSubmitLoading] = useState(false);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!formData.fullName || !formData.companyEmail) return;

    setSubmitLoading(true);
    // Simulate luxury API transit loop
    setTimeout(() => {
      setSubmitLoading(false);
      setFormSubmitted(true);
    }, 1200);
  };

  const handleReset = () => {
    setFormData({
      fullName: '',
      companyEmail: '',
      category: 'pouches',
      volume: '20k-50k',
      specifications: ''
    });
    setFormSubmitted(false);
  };

  return (
    <section id="contact" className="relative py-28 bg-[#F8F9FD] overflow-hidden scroll-mt-20">
      
      {/* Background soft glowing backdrops */}
      <div className="absolute top-[20%] right-[-10%] w-[35vw] h-[35vw] rounded-full bg-purple-100/15 blur-[120px] animate-glow-pulse-1 pointer-events-none" />
      <div className="absolute bottom-[20%] left-[-15%] w-[40vw] h-[40vw] rounded-full bg-blue-50/20 blur-[100px] animate-glow-pulse-2 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 md:px-12 relative z-10">
        
        {/* Main Grid split */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-start">
          
          {/* Left Column: Premium Contact Credentials */}
          <div className="lg:col-span-5 space-y-10 lg:sticky lg:top-28">
            
            <div className="space-y-4">
              <div className="inline-flex items-center space-x-2 bg-white border border-purple-100/85 px-3.5 py-1 rounded-full w-fit shadow-xs">
                <span className="w-1.5 h-1.5 rounded-full bg-purple-500" />
                <span className="text-[10px] font-sans font-bold tracking-widest text-[#a855f7] uppercase">
                  Get In Touch
                </span>
              </div>
              <h2 className="text-3xl md:text-5.5xl font-light tracking-tight text-slate-900 leading-[1.05]">
                Begin Your <span className="font-serif italic text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-blue-500">Packaging</span> Evolution
              </h2>
              <p className="font-sans text-sm md:text-base text-slate-500 font-light leading-relaxed max-w-sm">
                Have an upcoming launching or restructuring campaign? Provide specifications below to arrange high-fidelity physical prototype proofs.
              </p>
            </div>

            {/* Structured Contact Elements */}
            <div className="space-y-6">
              
              {/* Phone element */}
              <div className="flex items-start space-x-4">
                <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center shrink-0 shadow-2xs">
                  <Phone className="w-4.5 h-4.5" />
                </div>
                <div>
                  <span className="text-[10px] font-mono tracking-widest text-slate-400 uppercase font-semibold">
                    Call Operational Desk
                  </span>
                  <a href="tel:+6129881726" className="font-sans font-medium text-slate-800 block hover:text-purple-600 transition-colors mt-0.5 text-sm">
                    +61 (2) 9881 7268 (Sydney HQ)
                  </a>
                  <a href="tel:+8136338827" className="font-sans font-normal text-slate-400 block text-xs hover:text-purple-600 transition-colors mt-0.5">
                    +81 (3) 6338 8279 (Tokyo Hub)
                  </a>
                </div>
              </div>

              {/* Email element */}
              <div className="flex items-start space-x-4">
                <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center shrink-0 shadow-2xs">
                  <Mail className="w-4.5 h-4.5" />
                </div>
                <div>
                  <span className="text-[10px] font-mono tracking-widest text-slate-400 uppercase font-semibold">
                    Email Procurement Desk
                  </span>
                  <a href="mailto:inquire@mpack-print.com" className="font-sans font-medium text-slate-800 block hover:text-purple-600 transition-colors mt-0.5 text-sm">
                    inquire@mpack-print.com
                  </a>
                </div>
              </div>

              {/* Address pinpoint */}
              <div className="flex items-start space-x-4">
                <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center shrink-0 shadow-2xs">
                  <MapPin className="w-4.5 h-4.5" />
                </div>
                <div>
                  <span className="text-[10px] font-mono tracking-widest text-slate-400 uppercase font-semibold">
                    Our Physical Offices
                  </span>
                  <p className="font-sans text-[13px] text-slate-500 font-light mt-0.5">
                    Level 14, Martin Place, Sydney, NSW 2000, Australia
                  </p>
                  <p className="font-sans text-[11.5px] text-slate-400 font-light mt-1">
                    Tokyo: Roppongi Hills, Minato-ku, Tokyo 106-6108, Japan
                  </p>
                </div>
              </div>

            </div>

            {/* WA Direct Action Button (CTA) */}
            <div className="pt-4 border-t border-slate-100">
              <span className="text-[9px] font-mono tracking-widest text-slate-400 uppercase block mb-3 font-semibold">
                Immediate mobile chat support
              </span>
              <a
                href="https://wa.me/3100000000?text=Hello%20MPACK!%20I%20would%20like%20to%20discuss%20a%20packaging%20project."
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center space-x-3 bg-emerald-50 hover:bg-emerald-100/70 border border-emerald-200/40 text-emerald-800 font-sans font-medium text-xs tracking-wider uppercase py-3.5 px-6 rounded-full transition-all duration-300 hover:shadow-md"
              >
                <MessageCircle className="w-4 h-4 text-emerald-650 fill-emerald-600/10" />
                <span>Enquire via WhatsApp</span>
              </a>
            </div>

          </div>

          {/* Right Column: Sleek Inquiry Form Card layout */}
          <div className="lg:col-span-7">
            <div className="bg-white rounded-[2.5rem] border border-slate-100 p-8 sm:p-10 shadow-2xl shadow-purple-100/10 relative overflow-hidden">
              
              <AnimatePresence mode="wait">
                {!formSubmitted ? (
                  <motion.form
                    key="contact-form"
                    onSubmit={handleSubmit}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="space-y-6"
                  >
                    
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                      {/* Name */}
                      <div className="space-y-2">
                        <label className="text-[10px] font-mono tracking-widest text-slate-400 uppercase font-bold">
                          Your Full Name
                        </label>
                        <input
                          type="text"
                          required
                          value={formData.fullName}
                          onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                          placeholder="Your Name"
                          className="w-full bg-[#F8F9FD] border border-purple-50 focus:border-purple-300 rounded-2xl px-4 py-3 text-sm text-slate-800 outline-hidden transition-all placeholder-slate-400"
                        />
                      </div>

                      {/* Email */}
                      <div className="space-y-2">
                        <label className="text-[10px] font-mono tracking-widest text-slate-400 uppercase font-bold">
                          Corporate Email Address
                        </label>
                        <input
                          type="email"
                          required
                          value={formData.companyEmail}
                          onChange={(e) => setFormData({ ...formData, companyEmail: e.target.value })}
                          placeholder="name@company.com"
                          className="w-full bg-[#F8F9FD] border border-purple-50 focus:border-purple-300 rounded-2xl px-4 py-3 text-sm text-slate-800 outline-hidden transition-all placeholder-slate-400"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                      {/* Category Selection Dropdown */}
                      <div className="space-y-2">
                        <label className="text-[10px] font-mono tracking-widest text-slate-400 uppercase font-bold">
                          Packaging Category
                        </label>
                        <select
                          value={formData.category}
                          onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                          className="w-full bg-[#F8F9FD] border border-purple-50 focus:border-purple-300 rounded-2xl px-4 py-3 text-sm text-slate-800 outline-hidden transition-all"
                        >
                          <option value="pouches">Stand-up & Zipper Pouches</option>
                          <option value="boxes">Custom Structural Boxes</option>
                          <option value="canisters">Paper Composite Canisters</option>
                          <option value="labels">High-End Product Labels</option>
                          <option value="sleeves">Conforming Shrink Sleeves</option>
                        </select>
                      </div>

                      {/* Target Volume Selection */}
                      <div className="space-y-2">
                        <label className="text-[10px] font-mono tracking-widest text-slate-400 uppercase font-bold">
                          Projected Run Volume
                        </label>
                        <select
                          value={formData.volume}
                          onChange={(e) => setFormData({ ...formData, volume: e.target.value })}
                          className="w-full bg-[#F8F9FD] border border-purple-50 focus:border-purple-300 rounded-2xl px-4 py-3 text-sm text-slate-800 outline-hidden transition-all"
                        >
                          <option value="5k-20k">5,000 &mdash; 20,000 (Short Mix)</option>
                          <option value="20k-50k">20,000 &mdash; 50,000 (Standard)</option>
                          <option value="50k-100k">50,000 &mdash; 100,000 (High Volume)</option>
                          <option value="100k+">100,000+ (Rotogravure Capacity)</option>
                        </select>
                      </div>
                    </div>

                    {/* Specifications */}
                    <div className="space-y-2">
                      <label className="text-[10px] font-mono tracking-widest text-slate-400 uppercase font-bold">
                        Brief Project Specifications
                      </label>
                      <textarea
                        rows={4}
                        value={formData.specifications}
                        onChange={(e) => setFormData({ ...formData, specifications: e.target.value })}
                        placeholder="E.g., Matte velvet zipper pouches for organic spices, size 150g with transparent window highlight..."
                        className="w-full bg-[#F8F9FD] border border-purple-50 focus:border-purple-300 rounded-2xl px-4 py-3 text-sm text-slate-800 outline-hidden transition-all placeholder-slate-400 resize-none animate-fade-in"
                      />
                    </div>

                    {/* Submit */}
                    <button
                      type="submit"
                      disabled={submitLoading}
                      className="w-full relative group overflow-hidden bg-slate-900 hover:bg-[#a855f7] disabled:bg-slate-300 text-white font-sans font-semibold text-xs tracking-wider uppercase py-4 rounded-xl transition-all duration-500 hover:shadow-xl hover:shadow-purple-200/50 flex items-center justify-center space-x-2.5 cursor-pointer"
                    >
                      {submitLoading ? (
                        <span>Transmission routing...</span>
                      ) : (
                        <>
                          <span>Transmit Procurement Brief</span>
                          <Send className="w-3.5 h-3.5 transform group-hover:translate-x-1 group-hover:-translate-y-0.5 transition-transform" />
                        </>
                      )}
                    </button>

                  </motion.form>
                ) : (
                  <motion.div
                    key="success-card"
                    initial={{ scale: 0.96, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    exit={{ scale: 0.96 }}
                    className="text-center py-10 space-y-6"
                  >
                    <div className="w-16 h-16 rounded-full bg-purple-50 text-[#a855f7] flex items-center justify-center mx-auto shadow-inner">
                      <CheckSquare className="w-8 h-8" />
                    </div>

                    <div className="space-y-2.5">
                      <h3 className="text-2xl font-light text-slate-900 tracking-tight">
                        Inquiry Brief Transmitted
                      </h3>
                      <p className="font-sans text-sm text-[#475569] leading-relaxed font-light max-w-sm mx-auto">
                        Thank you, <span className="font-semibold text-slate-700">{formData.fullName}</span>. Your request has been assigned to our lead structural packaging engineer. Expect a digital draft blueprint review within 12 business hours.
                      </p>
                    </div>

                    {/* Back button */}
                    <button
                      onClick={handleReset}
                      className="text-xs font-mono font-semibold tracking-wider uppercase text-[#a855f7] hover:text-purple-700 underline pt-4 cursor-pointer font-bold"
                    >
                      File another inquiry brief
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>

            </div>
          </div>

        </div>

      </div>
    </section>
  );
}
