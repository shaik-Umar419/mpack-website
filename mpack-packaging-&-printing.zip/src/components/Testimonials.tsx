import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, ChevronLeft, ChevronRight, Star, Quote } from 'lucide-react';
import { clientTestimonials } from '../data';

export default function Testimonials() {
  const [activeIndex, setActiveIndex] = useState(0);
  const autoPlayRef = useRef<(() => void) | null>(null);

  const nextTestimonial = () => {
    setActiveIndex((prev) => (prev === clientTestimonials.length - 1 ? 0 : prev + 1));
  };

  const prevTestimonial = () => {
    setActiveIndex((prev) => (prev === 0 ? clientTestimonials.length - 1 : prev - 1));
  };

  // Capture the action in ref to avoid effect trigger stale states
  useEffect(() => {
    autoPlayRef.current = nextTestimonial;
  });

  useEffect(() => {
    const play = () => {
      autoPlayRef.current?.();
    };
    const timer = setInterval(play, 6500); // smooth luxury interval transitions
    return () => clearInterval(timer);
  }, []);

  return (
    <section id="testimonials" className="relative py-28 bg-[#F8F9FD] overflow-hidden scroll-mt-20">
      
      {/* Dynamic Glow Balls */}
      <div className="absolute top-[25%] left-[-10%] w-[35vw] h-[35vw] rounded-full bg-purple-100/10 blur-[120px] animate-glow-pulse-1 pointer-events-none" />
      <div className="absolute bottom-[20%] right-[-10%] w-[40vw] h-[40vw] rounded-full bg-blue-50/20 blur-[120px] animate-glow-pulse-2 pointer-events-none" />

      <div className="max-w-5xl mx-auto px-6 md:px-12 relative z-10">
        
        {/* Header Block */}
        <div className="text-center max-w-xl mx-auto mb-16 space-y-4">
          <div className="inline-flex items-center space-x-2 bg-white border border-purple-100/80 px-3 py-1 rounded-full shadow-xs">
            <span className="w-1.5 h-1.5 rounded-full bg-purple-500" />
            <span className="text-[10px] font-sans font-bold tracking-widest text-[#a855f7] uppercase font-semibold">
              Global Validation
            </span>
          </div>
          <h2 className="text-3xl md:text-5xl font-light tracking-tight text-slate-900">
            Partner <span className="font-serif italic text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-blue-500">Perspectives</span> & Reviews
          </h2>
          <p className="font-sans text-sm text-slate-500 font-light leading-relaxed">
            Read what elite consumer brand owners say, appreciating our material weight, delta-E color consistency, and fast structural sample deliveries.
          </p>
        </div>

        {/* Glassmorphic Carousel Framework */}
        <div className="relative min-h-[380px] sm:min-h-[340px] flex items-center justify-center">
          
          <AnimatePresence mode="wait">
            <motion.div
              key={activeIndex}
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
              className="bg-white w-full py-10 px-6 sm:px-12 rounded-[2.5rem] shadow-xl shadow-purple-100/10 relative overflow-hidden flex flex-col md:flex-row gap-8 items-start justify-between border border-slate-100"
            >
              
              {/* Backside giant Quote block symbol */}
              <div className="absolute top-4 right-6 text-purple-100/40 pointer-events-none select-none">
                <Quote className="w-24 h-24 stroke-[1px]" />
              </div>

              {/* Core Quote details */}
              <div className="flex-1 space-y-6 relative z-10">
                {/* Star rating component block */}
                <div className="flex items-center space-x-1">
                  {[...Array(clientTestimonials[activeIndex].rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 text-amber-400 fill-amber-400" />
                  ))}
                  <span className="text-[10px] font-mono font-medium text-slate-400 block ml-2">
                    5.0 RATED
                  </span>
                </div>

                <p className="font-sans text-base sm:text-[17px] text-slate-700 italic font-light leading-relaxed">
                  "{clientTestimonials[activeIndex].quote}"
                </p>

                {/* Author Credentials Row */}
                <div className="flex items-center space-x-4">
                  {/* Luxury initials monogram */}
                  <div className="w-11 h-11 rounded-full bg-slate-900 text-white flex items-center justify-center font-sans font-bold text-sm tracking-widest shadow-xs">
                    {clientTestimonials[activeIndex].initials}
                  </div>
                  <div>
                    <span className="font-sans font-semibold text-sm text-[#1e293b] block">
                      {clientTestimonials[activeIndex].author}
                    </span>
                    <span className="font-sans text-xs text-[#a855f7] font-medium">
                      {clientTestimonials[activeIndex].role} &mdash; <span className="text-slate-400 font-light">{clientTestimonials[activeIndex].company}</span>
                    </span>
                  </div>
                </div>

              </div>

            </motion.div>
          </AnimatePresence>

          {/* Left Caret clicker */}
          <button
            onClick={prevTestimonial}
            className="absolute left-[-20px] top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white border border-slate-150 flex items-center justify-center text-slate-500 hover:text-purple-600 shadow-lg hover:shadow-xl hover:scale-105 transition-all cursor-pointer z-20"
            aria-label="Previous testimonial"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>

          {/* Right Caret clicker */}
          <button
            onClick={nextTestimonial}
            className="absolute right-[-20px] top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white border border-slate-150 flex items-center justify-center text-slate-500 hover:text-purple-600 shadow-lg hover:shadow-xl hover:scale-105 transition-all cursor-pointer z-20"
            aria-label="Next testimonial"
          >
            <ChevronRight className="w-5 h-5" />
          </button>

        </div>

        {/* Index bullet indicators block */}
        <div className="flex items-center justify-center space-x-2.5 mt-8">
          {clientTestimonials.map((_, index) => (
            <button
              key={index}
              onClick={() => setActiveIndex(index)}
              className={`h-2 rounded-full transition-all duration-500 cursor-pointer ${
                index === activeIndex
                  ? 'bg-purple-600 w-7'
                  : 'bg-purple-200/50 hover:bg-purple-300 w-2'
              }`}
              aria-label={`Go to slide ${index + 1}`}
            />
          ))}
        </div>

      </div>
    </section>
  );
}
