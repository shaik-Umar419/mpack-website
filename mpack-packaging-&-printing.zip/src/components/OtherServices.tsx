import { motion } from 'motion/react';
import { 
  Sparkles, 
  PenTool, 
  Cpu, 
  Tag, 
  QrCode, 
  Layers, 
  ArrowRight,
  Check 
} from 'lucide-react';
import { luxuryServices } from '../data';

export default function OtherServices() {
  // Map service icon string to Lucide component
  const getServiceIcon = (id: string, className: string) => {
    switch (id) {
      case 'designing':
        return <PenTool className={className} />;
      case 'machinery':
        return <Cpu className={className} />;
      case 'labelling':
        return <Tag className={className} />;
      case 'barcode':
        return <QrCode className={className} />;
      case 'converter':
        return <Layers className={className} />;
      default:
        return <Layers className={className} />;
    }
  };

  return (
    <section id="services" className="relative py-28 bg-[#F8F9FD] overflow-hidden scroll-mt-20">
      
      {/* Soft Glow Background Accents */}
      <div className="absolute top-[20%] right-[-10%] w-[35vw] h-[35vw] rounded-full bg-purple-100/20 blur-[130px] animate-glow-pulse-1 pointer-events-none" />
      <div className="absolute bottom-[20%] left-[-10%] w-[40vw] h-[40vw] rounded-full bg-blue-50/20 blur-[100px] animate-glow-pulse-2 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 md:px-12 relative z-10">
        
        {/* Header Block */}
        <div className="text-center max-w-2xl mx-auto mb-20 space-y-4">
          <div className="inline-flex items-center space-x-2 bg-white border border-purple-100/80 px-3 py-1 rounded-full shadow-xs">
            <span className="w-1.5 h-1.5 rounded-full bg-purple-500" />
            <span className="text-[10px] font-sans font-bold tracking-widest text-[#a855f7] uppercase font-semibold">
              End-to-End Solutions
            </span>
          </div>
          <h2 className="text-3xl md:text-5xl font-light tracking-tight text-slate-900">
            Design <span className="font-serif italic text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-blue-500">Studios</span> & Services
          </h2>
          <p className="font-sans text-sm md:text-base text-slate-500 font-light max-w-xl mx-auto leading-relaxed">
            Beyond physical print, we support supply-chains with expert labeling, GS1 standard placement, and structural consulting.
          </p>
        </div>

        {/* Services staggered grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {luxuryServices.map((service, idx) => {
            return (
              <motion.div
                key={service.id}
                initial={{ opacity: 0, y: 35 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-80px" }}
                transition={{ duration: 0.8, delay: idx * 0.1, ease: [0.16, 1, 0.3, 1] }}
                className="group relative p-8 rounded-[2.2rem] bg-white border border-slate-100 hover:border-[#a855f7]/30 shadow-xs hover:shadow-2xl transition-all duration-500 flex flex-col justify-between min-h-[360px] cursor-default"
              >
                
                {/* Floating internal layout detail */}
                <div className="space-y-6">
                  
                  {/* Service Card Top header */}
                  <div className="flex items-center justify-between">
                    <div className="w-12 h-12 rounded-2xl bg-purple-50/70 text-[#a855f7] flex items-center justify-center transition-all duration-500 group-hover:bg-[#a855f7] group-hover:text-white group-hover:scale-110 shadow-3xs">
                      {getServiceIcon(service.id, "w-5.5 h-5.5")}
                    </div>
                    <span className="text-[9px] font-mono tracking-widest text-slate-300 uppercase">
                      Code: {service.id}
                    </span>
                  </div>

                  {/* Card Content details */}
                  <div className="space-y-2.5">
                    <h3 className="text-base font-medium text-slate-800 group-hover:text-purple-600 transition-colors">
                      {service.title}
                    </h3>
                    <p className="font-sans text-[13px] text-slate-500 font-light leading-relaxed">
                      {service.description}
                    </p>
                  </div>

                  {/* Features list bullet points */}
                  <div className="space-y-2 pt-2">
                    {service.benefits.map((ben, i) => (
                      <div key={i} className="flex items-center space-x-2.5">
                        <Check className="w-3.5 h-3.5 text-[#a855f7]" />
                        <span className="text-[12px] font-sans text-slate-600 font-light">
                          {ben}
                        </span>
                      </div>
                    ))}
                  </div>

                </div>

                {/* Micro interactivity footer inside card */}
                <div className="mt-8 pt-5 border-t border-slate-50 flex items-center justify-between text-slate-400 group-hover:text-purple-600 transition-colors text-[10px] font-mono tracking-wide">
                  <span>Consult An Architect</span>
                  <ArrowRight className="w-3.5 h-3.5 transform group-hover:translate-x-1.5 transition-transform" />
                </div>

              </motion.div>
            );
          })}
        </div>

      </div>
    </section>
  );
}
