import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';

interface LoadingScreenProps {
  onComplete: () => void;
}

export default function LoadingScreen({ onComplete }: LoadingScreenProps) {
  const [progress, setProgress] = useState(0);
  const [fadeOut, setFadeOut] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(() => {
            setFadeOut(true);
            setTimeout(onComplete, 800);
          }, 400);
          return 100;
        }
        // slow progress at the end for realistic luxury loading
        const increment = prev > 70 ? Math.random() * 4 + 1 : Math.random() * 15 + 5;
        return Math.min(prev + increment, 100);
      });
    }, 90);

    return () => clearInterval(interval);
  }, [onComplete]);

  return (
    <AnimatePresence>
      {!fadeOut && (
        <motion.div
          id="loading-overlay"
          initial={{ opacity: 1 }}
          exit={{ opacity: 0, filter: 'blur(20px)' }}
          transition={{ duration: 0.8, ease: [0.76, 0, 0.24, 1] }}
          className="fixed inset-0 z-[999] flex flex-col items-center justify-center bg-[#fdfcff] overflow-hidden"
        >
          {/* Subtle luxurious glowing background particles */}
          <div className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full bg-violet-200/30 blur-[90px] animate-glow-pulse-1" />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 rounded-full bg-blue-100/35 blur-[100px] animate-glow-pulse-2" />

          {/* Core Content */}
          <div className="relative z-10 flex flex-col items-center max-w-sm px-6 text-center">
            {/* Elegant Logo Emblem */}
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
              className="mb-8 flex items-center justify-center w-14 h-14 rounded-full border border-violet-200 bg-white/60 backdrop-blur-md shadow-xs"
            >
              <div className="w-6 h-6 rounded-xs bg-gradient-to-tr from-violet-600 to-indigo-400 opacity-90 transform rotate-45" />
            </motion.div>

            {/* Brand Letters Stagger */}
            <div className="flex space-x-2 tracking-[0.25em] text-2xl font-display font-light text-gray-800 ml-[0.25em]">
              {"MPACK".split('').map((char, index) => (
                <motion.span
                  key={index}
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{
                    duration: 1.2,
                    delay: index * 0.1,
                    ease: [0.16, 1, 0.3, 1]
                  }}
                >
                  {char}
                </motion.span>
              ))}
            </div>

            {/* Subtext */}
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.5 }}
              transition={{ delay: 0.6, duration: 1 }}
              className="mt-3 text-xs uppercase tracking-[0.3em] font-sans font-medium text-gray-700"
            >
              Artistry in Presentation
            </motion.p>

            {/* Loading Bar Container */}
            <div className="mt-14 w-48 h-[2px] bg-gray-100 rounded-full overflow-hidden relative">
              <motion.div
                className="h-full bg-gradient-to-r from-violet-500 to-indigo-400 rounded-full"
                style={{ width: `${progress}%` }}
                layoutId="progressBar"
              />
            </div>

            {/* Text Percentage */}
            <motion.span
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.4 }}
              className="mt-3 text-[10px] font-mono tracking-widest text-gray-600"
            >
              {Math.round(progress)}%
            </motion.span>
          </div>

          {/* Technical label for premium atmosphere */}
          <div className="absolute bottom-8 text-[9px] font-mono tracking-[0.4em] text-gray-400 uppercase opacity-60">
            Est. 2011 — Sydney & Tokyo Standard
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
