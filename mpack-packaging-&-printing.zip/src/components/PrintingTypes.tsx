import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, Printer, Zap, Cpu, RefreshCw, Layers, Sliders, CheckCircle } from 'lucide-react';
import { printingTypes } from '../data';

export default function PrintingTypes() {
  const [activeId, setActiveId] = useState<string>("digital");

  // Map icon strings to Lucide components
  const getIcon = (id: string, className: string) => {
    switch (id) {
      case 'digital':
        return <Zap className={className} />;
      case 'rotogravure':
        return <Printer className={className} />;
      case 'flexographic':
        return <Layers className={className} />;
      case 'offset':
        return <RefreshCw className={className} />;
      case 'hybrid':
        return <Cpu className={className} />;
      default:
        return <Sliders className={className} />;
    }
  };

  return (
    <section id="printing-tech" className="relative py-28 bg-[#F8F9FD] overflow-hidden scroll-mt-20">
      
      {/* Background Soft Gradients */}
      <div className="absolute top-[30%] right-[-10%] w-[35vw] h-[35vw] rounded-full bg-purple-100/20 blur-[120px] animate-glow-pulse-1 pointer-events-none" />
      <div className="absolute bottom-[20%] left-[-15%] w-[40vw] h-[40vw] rounded-full bg-blue-50/30 blur-[100px] animate-glow-pulse-2 pointer-events-none" />
      
      <div className="max-w-7xl mx-auto px-6 md:px-12 relative z-10">
        
        {/* Header Elements */}
        <div className="text-center max-w-2xl mx-auto mb-20 space-y-4">
          <div className="inline-flex items-center space-x-2 bg-white border border-purple-100/80 px-3 py-1 rounded-full shadow-xs">
            <span className="w-1.5 h-1.5 rounded-full bg-purple-500" />
            <span className="text-[10px] font-sans font-bold tracking-widest text-[#a855f7] uppercase">
              Manufacturing Technology
            </span>
          </div>
          <h2 className="text-3xl md:text-5xl font-light tracking-tight text-slate-900">
            Bespoke <span className="font-serif italic text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-blue-500">Printing</span> Systems
          </h2>
          <p className="font-sans text-sm md:text-base text-slate-500 font-light max-w-xl mx-auto leading-relaxed">
            Aligning multi-million dollar machinery lines with bespoke design requests to deliver vibrant precision. Examine our technical benchmarks.
          </p>
        </div>

        {/* Desktop Split-Grid: Floating Selector Left, Expansive Spec Details Right */}
        <div className="hidden lg:grid grid-cols-12 gap-8 items-stretch min-h-[550px]">
          
          {/* Left Column: Interactive Cards Menu */}
          <div className="col-span-5 flex flex-col space-y-4">
            {printingTypes.map((type) => {
              const isActive = activeId === type.id;
              return (
                <button
                  key={type.id}
                  onClick={() => setActiveId(type.id)}
                  onMouseEnter={() => setActiveId(type.id)}
                  className={`text-left p-6 rounded-[2rem] border transition-all duration-500 cursor-pointer flex items-center space-x-4 group ${
                    isActive
                      ? 'bg-white border-purple-100 shadow-xl shadow-purple-100/20 scale-[1.02]'
                      : 'bg-white/65 hover:bg-white border-slate-100 hover:border-purple-200/50 hover:shadow-xs hover:scale-[1.01]'
                  }`}
                >
                  <div className={`w-12 h-12 rounded-2xl flex items-center justify-center transition-all duration-500 ${
                    isActive
                      ? 'bg-slate-900 text-white glow-purple'
                      : 'bg-purple-55 text-purple-600 group-hover:bg-purple-100'
                  }`}>
                    {getIcon(type.id, "w-6 h-6")}
                  </div>

                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <span className="text-base font-medium text-slate-800 tracking-tight">
                        {type.title}
                      </span>
                      <span className={`text-[9px] font-mono uppercase tracking-widest px-2.5 py-0.5 rounded-full ${
                        isActive
                          ? 'bg-purple-500/10 text-purple-700 font-semibold'
                          : 'bg-slate-100 text-slate-400'
                      }`}>
                        {type.badge}
                      </span>
                    </div>
                    <p className="font-sans text-xs text-slate-400 mt-1 line-clamp-1 font-light">
                      {type.description}
                    </p>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Right Column: High Fidelity Specs Display panel */}
          <div className="col-span-7">
            <AnimatePresence mode="wait">
              {printingTypes.map((type) => {
                if (type.id !== activeId) return null;
                return (
                  <motion.div
                    key={type.id}
                    initial={{ opacity: 0, scale: 0.98, filter: 'blur(10px)' }}
                    animate={{ opacity: 1, scale: 1, filter: 'blur(0px)' }}
                    exit={{ opacity: 0, scale: 0.98, filter: 'blur(10px)' }}
                    transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
                    className="h-full bg-white rounded-[2rem] border border-purple-50 p-10 flex flex-col justify-between shadow-2xl shadow-purple-100/35 relative overflow-hidden"
                  >
                    {/* Glowing structural laser background highlights */}
                    <div className="absolute top-0 right-0 w-64 h-64 bg-radial from-purple-200/20 to-transparent blur-3xl pointer-events-none" />

                    <div className="space-y-8">
                      {/* Title & badge */}
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <div className="w-10 h-10 rounded-xl bg-purple-50 flex items-center justify-center text-purple-600">
                            {getIcon(type.id, "w-5 h-5")}
                          </div>
                          <h3 className="text-2xl font-light text-slate-900 tracking-tight">
                            {type.title}
                          </h3>
                        </div>
                        <span className="text-xs font-mono bg-purple-600 text-white font-semibold px-4 py-1 rounded-full uppercase tracking-wider">
                          {type.badge}
                        </span>
                      </div>

                      {/* Decription */}
                      <p className="font-sans text-slate-500 leading-relaxed font-light text-[15px]">
                        {type.description}
                       </p>

                      {/* Advantages */}
                      <div className="space-y-3">
                        <span className="text-[10px] font-mono tracking-widest text-[#a855f7] uppercase font-semibold">
                          Core Operational Advantages
                        </span>
                        <div className="space-y-2">
                          {type.advantages.map((adv) => (
                            <div key={adv} className="flex items-start space-x-3">
                              <CheckCircle className="w-4 h-4 text-purple-600 shrink-0 mt-0.5" />
                              <span className="font-sans text-sm text-[#1e293b] font-light leading-tight">
                                {adv}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>

                    {/* Operational Benchmarks */}
                    <div className="mt-8 pt-8 border-t border-slate-100 grid grid-cols-3 gap-6">
                      {type.specs.map((spec) => (
                        <div key={spec.label} className="space-y-1.5">
                          <span className="text-[9px] font-mono uppercase tracking-widest text-slate-400">
                            {spec.label}
                          </span>
                          <p className="text-slate-800 text-sm font-medium tracking-tight leading-none">
                            {spec.value}
                          </p>
                        </div>
                      ))}
                    </div>

                  </motion.div>
                );
              })}
            </AnimatePresence>
          </div>

        </div>

        {/* Mobile Accordion Grid */}
        <div className="lg:hidden space-y-4">
          {printingTypes.map((type) => {
            const isExpanded = activeId === type.id;
            return (
              <div
                key={type.id}
                className="bg-white border border-slate-100 rounded-[1.5rem] overflow-hidden shadow-xs transition-all duration-300"
              >
                <button
                  onClick={() => setActiveId(isExpanded ? "" : type.id)}
                  className="w-full p-5 flex items-center justify-between text-left cursor-pointer"
                >
                  <div className="flex items-center space-x-3">
                    <div className="w-9 h-9 rounded-lg bg-purple-50 flex items-center justify-center text-purple-600">
                      {getIcon(type.id, "w-5 h-5")}
                    </div>
                    <div>
                      <h3 className="text-sm font-medium text-slate-800">
                        {type.title}
                      </h3>
                      <p className="text-[9px] uppercase font-mono text-slate-400 mt-0.5">
                        {type.badge}
                      </p>
                    </div>
                  </div>
                  <div className={`w-6 h-6 rounded-full bg-slate-50 flex items-center justify-center text-slate-400 transition-transform duration-300 ${
                    isExpanded ? 'rotate-180' : ''
                  }`}>
                    <Sliders className="w-3 h-3" />
                  </div>
                </button>

                <AnimatePresence initial={false}>
                  {isExpanded && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.3 }}
                    >
                      <div className="px-5 pb-6 pt-2 border-t border-slate-50 space-y-5">
                        <p className="font-sans text-xs text-slate-500 leading-relaxed">
                          {type.description}
                        </p>

                        <div className="space-y-2">
                          {type.advantages.map((adv) => (
                            <div key={adv} className="flex items-start space-x-2.5">
                              <CheckCircle className="w-3.5 h-3.5 text-purple-600 shrink-0 mt-0.5" />
                              <span className="font-sans text-xs text-slate-500">
                                {adv}
                              </span>
                            </div>
                          ))}
                        </div>

                        <div className="pt-4 border-t border-slate-50 grid grid-cols-3 gap-2">
                          {type.specs.map((spec) => (
                            <div key={spec.label}>
                              <span className="text-[8px] font-mono uppercase tracking-wider text-slate-400 block mb-0.5">
                                {spec.label}
                              </span>
                              <span className="font-medium text-[11px] text-slate-800 leading-tight block">
                                {spec.value}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
}
