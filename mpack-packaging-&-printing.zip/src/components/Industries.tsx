import { motion } from 'motion/react';
import { 
  Sparkles, 
  Flame, 
  Apple, 
  Snowflake, 
  ShoppingBag, 
  Boxes, 
  ChefHat 
} from 'lucide-react';
import { servedIndustries } from '../data';

export default function Industries() {
  // Map industry keys to bespoke Lucide icons
  const getIndustryIcon = (id: string, className: string) => {
    switch (id) {
      case 'spices':
        return <Flame className={className} />;
      case 'dryfruits':
        return <Apple className={className} />;
      case 'frozen':
        return <Snowflake className={className} />;
      case 'retail':
        return <ShoppingBag className={className} />;
      case 'fmcg':
        return <Boxes className={className} />;
      case 'food':
        return <ChefHat className={className} />;
      default:
        return <Boxes className={className} />;
    }
  };

  return (
    <section id="industries" className="relative py-28 bg-[#F8F9FD] overflow-hidden scroll-mt-20">
      
      {/* Background Soft Purple Glow Spheres */}
      <div className="absolute top-[30%] left-[-10%] w-[35vw] h-[35vw] rounded-full bg-purple-100/10 blur-[120px] animate-glow-pulse-1 pointer-events-none" />
      <div className="absolute bottom-[10%] right-[-10%] w-[35vw] h-[35vw] rounded-full bg-blue-50/20 blur-[100px] animate-glow-pulse-2 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 md:px-12 relative z-10">
        
        {/* Header content */}
        <div className="text-center max-w-2xl mx-auto mb-20 space-y-4">
          <div className="inline-flex items-center space-x-2 bg-white border border-purple-100/80 px-3 py-1 rounded-full shadow-xs">
            <span className="w-1.5 h-1.5 rounded-full bg-purple-500" />
            <span className="text-[10px] font-sans font-bold tracking-widest text-[#a855f7] uppercase font-semibold">
              Market Adaptability
            </span>
          </div>
          <h2 className="text-3xl md:text-5xl font-light tracking-tight text-slate-900">
            Sectors & <span className="font-serif italic text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-blue-500">Consumer</span> Markets
          </h2>
          <p className="font-sans text-sm md:text-base text-slate-500 font-light max-w-xl mx-auto leading-relaxed">
            From temperature-resistant frozen seals to high-fidelity cosmetics foil inserts, we engineer client solutions targeted to specific category compliance.
          </p>
        </div>

        {/* Dynamic Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {servedIndustries.map((ind, idx) => {
            return (
              <motion.div
                key={ind.id}
                initial={{ opacity: 0, y: 35 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-80px" }}
                transition={{ duration: 0.8, delay: idx * 0.08, ease: [0.16, 1, 0.3, 1] }}
                className={`group relative p-8 md:p-10 rounded-[2.2rem] bg-white border border-slate-100 hover:border-purple-200/50 transition-all duration-500 cursor-default flex flex-col justify-between min-h-[260px] hover:shadow-xl hover:shadow-purple-100/10`}
              >
                
                {/* Micro glow behind card */}
                <div className="absolute inset-0 bg-radial from-purple-600/[0.01] to-transparent pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity" />

                {/* Card Icon Header */}
                <div className="flex items-center justify-between">
                  <div className={`w-12 h-12 rounded-2xl flex items-center justify-center transition-all duration-500 group-hover:scale-110 shadow-2xs group-hover:shadow-sm ${ind.accentClass} bg-white border border-slate-50`}>
                    {getIndustryIcon(ind.id, "w-6 h-6")}
                  </div>

                  <span className="text-[10px] font-mono tracking-widest text-[#a855f7] uppercase font-semibold">
                    Secured Case: {ind.id}
                  </span>
                </div>

                {/* Card Body */}
                <div className="mt-8 space-y-3.5">
                  <h3 className="text-lg font-medium text-slate-900 group-hover:text-purple-600 transition-colors">
                    {ind.name}
                  </h3>
                  <p className="font-sans text-[13px] text-slate-500 font-light leading-relaxed">
                    {ind.description}
                  </p>
                </div>

                {/* Operational indicator line */}
                <div className="mt-6 pt-5 border-t border-slate-100 flex items-center justify-between text-slate-400 group-hover:text-purple-500 transition-colors text-[10px] font-mono tracking-wider">
                  <span>Regulatory Approved</span>
                  <span className="w-2 h-2 rounded-full bg-emerald-400 group-hover:animate-ping" title="Active validation" />
                </div>

              </motion.div>
            );
          })}
        </div>

      </div>
    </section>
  );
}
