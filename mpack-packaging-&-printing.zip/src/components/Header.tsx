import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Menu, X, ArrowRight, Layers } from 'lucide-react';

interface HeaderProps {
  onContactClick: () => void;
}

export default function Header({ onContactClick }: HeaderProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 40);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const menuItems = [
    { label: 'About', href: '#about' },
    { label: 'Printing Tech', href: '#printing-tech' },
    { label: 'Product Showcase', href: '#showcase' },
    { label: 'Industries', href: '#industries' },
    { label: 'Our Services', href: '#services' },
    { label: 'Testimonials', href: '#testimonials' },
  ];

  return (
    <>
      <motion.header
        id="navbar-header"
        initial={{ y: -60, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1], delay: 0.5 }}
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          isScrolled
            ? 'py-4 bg-[#fcfbfe]/75 backdrop-blur-xl border-b border-violet-100/40 shadow-xs'
            : 'py-6 bg-transparent border-b border-transparent'
        }`}
      >
        <div className="max-w-7xl mx-auto px-6 md:px-12 flex items-center justify-between">
          {/* Logo */}
          <a href="#" className="group flex items-center space-x-3 text-gray-900 focus:outline-hidden">
            <div className="relative flex items-center justify-center w-9 h-9 rounded-full bg-linear-to-tr from-violet-600 to-indigo-500 shadow-sm transition-transform duration-500 group-hover:rotate-45">
              <Layers className="w-4.5 h-4.5 text-white" />
              <div className="absolute inset-0 rounded-full bg-violet-600/20 blur-md opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
            </div>
            <div>
              <span className="font-display text-lg font-bold tracking-[0.16em] uppercase">
                Mpack
              </span>
              <p className="text-[7.5px] font-mono uppercase tracking-[0.22em] text-gray-400 leading-none">
                Packaging & Print
              </p>
            </div>
          </a>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center space-x-9">
            {menuItems.map((item) => (
              <a
                key={item.label}
                href={item.href}
                className="relative text-sm font-sans font-medium text-gray-600 hover:text-violet-600 transition-colors duration-300 group py-1"
              >
                {item.label}
                <span className="absolute bottom-0 left-0 w-0 h-[1.5px] bg-violet-500 transition-all duration-300 group-hover:w-full" />
              </a>
            ))}
          </nav>

          {/* CTA & Mobile Toggle */}
          <div className="flex items-center space-x-4">
            <button
              onClick={onContactClick}
              className="px-5 py-2.5 bg-white shadow-sm border border-slate-100 rounded-full text-slate-800 hover:shadow-md hover:bg-slate-50 transition-all font-medium text-xs hidden md:inline-flex items-center space-x-1 font-sans cursor-pointer"
            >
              <span>Contact Us</span>
              <ArrowRight className="w-3.5 h-3.5 text-slate-400 group-hover:translate-x-1 transition-transform" />
            </button>

            {/* Mobile menu trigger */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="lg:hidden p-1.5 text-gray-700 hover:text-violet-600 transition-colors cursor-pointer"
              aria-label="Toggle menu"
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </motion.header>

      {/* Mobile Menu Slidedown Overlay */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.4, ease: 'easeInOut' }}
            className="fixed inset-x-0 top-[73px] z-45 bg-[#fcfbfe]/95 backdrop-blur-2xl border-b border-violet-100/50 md:hidden p-6 shadow-xl"
          >
            <div className="flex flex-col space-y-4">
              {menuItems.map((item) => (
                <a
                  key={item.label}
                  href={item.href}
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="text-base font-sans font-medium text-gray-700 hover:text-violet-600 transition-colors"
                >
                  {item.label}
                </a>
              ))}
              <hr className="border-violet-100/30 my-2" />
              <button
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  onContactClick();
                }}
                className="w-full flex items-center justify-center space-x-2 bg-violet-600 hover:bg-violet-700 text-white text-sm font-medium py-3 rounded-xl transition-colors cursor-pointer"
              >
                <span>Get In touch</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
