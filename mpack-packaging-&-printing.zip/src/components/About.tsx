import { motion } from 'motion/react';
import { ShieldCheck, CalendarRange, Cpu, Settings2, Sparkles, HelpCircle } from 'lucide-react';

export default function About() {
  const strengths = [
    {
      icon: ShieldCheck,
      title: "Quality-Focused Experts",
      description: "Our in-house densitometer quality control ensures delta-E color accuracy down to sub-pixel values. Every run is audited for registration alignment.",
      glowColor: "group-hover:border-violet-400 group-hover:bg-violet-50/10",
      iconColor: "text-violet-600 bg-violet-50"
    },
    {
      icon: CalendarRange,
      title: "Reliable Production Output",
      description: "Equipped with automated ink feeding lines and high-output machinery. We assure continuous capacity and redundant backup scheduling for prompt delivery.",
      glowColor: "group-hover:border-blue-400 group-hover:bg-blue-50/10",
      iconColor: "text-blue-600 bg-blue-50"
    },
    {
      icon: Cpu,
      title: "Ultra-Modern Machinery",
      description: "Operating multi-station flexo systems on state of the art European co-extrusion substrates, driving pristine definition on paper and synthetic films.",
      glowColor: "group-hover:border-teal-400 group-hover:bg-teal-50/10",
      iconColor: "text-teal-600 bg-teal-50"
    },
    {
      icon: Settings2,
      title: "Custom Packaging Support",
      description: "Work individually with our structural layout architects. We develop bespoke, custom-shaped pouch profiles and folding box nested enclosures to order.",
      glowColor: "group-hover:border-pink-400 group-hover:bg-pink-50/10",
      iconColor: "text-pink-600 bg-pink-50"
    }
  ];

  const timelineMilestones = [
    { year: "2011", label: "Founding Vision", desc: "Established original digital prepress offset workshop in Sydney to service local wine producers with micro-run craft adhesive labels." },
    { year: "2016", label: "Flexible Films Expansion", desc: "Commissioned primary cleanroom stand-up zipper pouch lines, accommodating gourmet spices and organic retail brands." },
    { year: "2021", label: "Smart Hybrid Machinery", desc: "Pioneered multi-station flexographic + high-speed digital hybrid lines, enabling zero-cylinder mass personalization." },
    { year: "2026", label: "Global Circular Design", desc: "Overhauled material library to support 100% biodegradable compostable barrier resins and plant-derived soy inks." }
  ];

  return (
    <section id="about" className="relative py-28 bg-[#F8F9FD] overflow-hidden scroll-mt-20">
      {/* Background gradients */}
      <div className="absolute top-[20%] left-[-10%] w-[35vw] h-[35vw] rounded-full bg-purple-100/40 blur-[100px] animate-glow-pulse-2 pointer-events-none" />
      <div className="absolute bottom-[10%] right-[-10%] w-[40vw] h-[40vw] rounded-full bg-blue-50/40 blur-[120px] animate-glow-pulse-1 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 md:px-12 relative z-10">
        
        {/* Split Section Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-start">
          
          {/* Left Column: Brand Vision & Text Reveal */}
          <div className="lg:col-span-5 space-y-8 lg:sticky lg:top-32">
            
            <div className="space-y-4">
              <div className="inline-flex items-center space-x-2 bg-white border border-purple-100/80 px-3 py-1 rounded-full w-fit shadow-xs">
                <span className="w-1.5 h-1.5 rounded-full bg-purple-500" />
                <span className="text-[10px] font-sans font-bold tracking-widest text-purple-600 uppercase">
                  Who We Are
                </span>
              </div>
              <h2 className="text-3xl md:text-4xl font-light tracking-tight text-slate-900 leading-[1.1]">
                Architecting the first point of <span className="font-serif italic text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-blue-500">tactile contact</span> with your consumer.
              </h2>
            </div>

            <p className="font-sans text-base text-slate-500 font-light leading-relaxed">
              At MPACK, we view packaging as a physical translation of your brand’s culinary, cosmetic, or retail soul. We do not manufacture mere containment envelopes; we architect premium brand experiences.
            </p>

            <p className="font-sans text-sm text-slate-500 font-light leading-relaxed border-l-2 border-purple-200 pl-4 py-1 italic">
              "We synthesize micro-precision chemistry, pristine material science, and high-DPI design to establish immediate confidence on boutique shelves."
            </p>

            {/* Micro stats banner inside About */}
            <div className="grid grid-cols-2 gap-4 pt-4 border-t border-slate-100">
              <div>
                <span className="font-sans font-bold text-lg text-purple-600">300+ Tons</span>
                <p className="text-[11px] font-sans text-slate-400">Monthly Flexible Film Output</p>
              </div>
              <div>
                <span className="font-sans font-bold text-lg text-blue-600">99.86%</span>
                <p className="text-[11px] font-sans text-slate-400">Client Delivery Commitment Rate</p>
              </div>
            </div>

          </div>

          {/* Right Column: Strengths Cards Grid */}
          <div className="lg:col-span-7 space-y-12">
            
            {/* Strengths Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {strengths.map((str, idx) => {
                const Icon = str.icon;
                return (
                  <motion.div
                    key={str.title}
                    initial={{ opacity: 0, y: 30 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true, margin: "-100px" }}
                    transition={{ duration: 0.8, delay: idx * 0.1, ease: [0.16, 1, 0.3, 1] }}
                    className={`group relative p-6 bg-white border border-slate-100 hover:shadow-xl rounded-[2rem] transition-all duration-500 cursor-default ${str.glowColor}`}
                  >
                    {/* Glow backdrop inside the card on hover */}
                    <div className="absolute inset-0 bg-radial from-purple-400/[0.015] via-transparent to-transparent pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                    
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center mb-5 transition-transform duration-500 group-hover:scale-110 ${str.iconColor}`}>
                      <Icon className="w-5 h-5" />
                    </div>

                    <h3 className="text-base font-medium text-slate-800 mb-2.5 tracking-tight">
                      {str.title}
                    </h3>
                    
                    <p className="font-sans text-[13px] text-slate-500 font-light leading-relaxed">
                      {str.description}
                    </p>
                  </motion.div>
                );
              })}
            </div>

            {/* Custom Interactive Brand Timeline Grid */}
            <div className="mt-10 p-6 sm:p-8 bg-white border border-slate-100 rounded-[2rem] shadow-xs">
              <h3 className="text-lg font-medium text-slate-900 mb-6 tracking-tight flex items-center space-x-2">
                <span className="w-2 h-2 rounded-full bg-purple-500" />
                <span>Our Structural Evolution</span>
              </h3>

              <div className="space-y-6 relative before:absolute before:left-3 before:top-2 before:bottom-2 before:w-[1px] before:bg-slate-100">
                {timelineMilestones.map((ms, idx) => (
                  <motion.div
                    key={ms.year}
                    initial={{ opacity: 0, x: -10 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.6, delay: idx * 0.1 }}
                    className="flex space-x-4 relative"
                  >
                    {/* Ring Indicator */}
                    <div className="relative z-10 w-6 h-6 rounded-full bg-[#F8F9FD] border-2 border-purple-400 flex items-center justify-center">
                      <div className="w-2 h-2 rounded-full bg-purple-500" />
                    </div>

                    <div className="flex-1 pb-4 border-b border-slate-100 last:border-0">
                      <div className="flex flex-col sm:flex-row sm:items-baseline sm:justify-between mb-1">
                        <span className="text-sm font-medium text-purple-700 tracking-wider">
                          {ms.label}
                        </span>
                        <span className="font-mono text-xs font-semibold text-slate-400">
                          {ms.year}
                        </span>
                      </div>
                      <p className="font-sans text-[12.5px] text-slate-500 font-light leading-relaxed">
                        {ms.desc}
                      </p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
